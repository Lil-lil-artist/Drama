let ChapterContent = document.getElementById("ChapterContent").value;  //这个chapter的内容
let ChapterTitles = document.getElementById("ChapterTitles").value; // ElectedAuthor提出的这个chapter的名字
let ElectedAuthor = document.getElementById("ElectedAuthor").value;  //被选出来写这一个chapter的ElectedAuthor