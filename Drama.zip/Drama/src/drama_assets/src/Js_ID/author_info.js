let ProposalAuthor = document.getElementById("author.id").value;//author.id
let ProposalAuthor = document.getElementById("proposal").value;//proposal
let ProposalAuthor = document.getElementById("work").value;//works
let ProposalAuthor = document.getElementById("exp").value;//Creation experience
let ProposalAuthor = document.getElementById("dsp").value;//description
let ProposalAuthor = document.getElementById("itd").value;//introduction
let ProposalAuthor = document.getElementById("idea").value;//idea
//头像还没加