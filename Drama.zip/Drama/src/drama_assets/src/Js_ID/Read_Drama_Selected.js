let ChapterStatus = document.getElementById("ChapterStatus").value; //这个Chapter的写作情况：Completed, In creation和Electing
let ChapterTitles = document.getElementById("ChapterTitles").value; // ElectedAuthor提出的这个chapter的名字
let ElectedAuthor = document.getElementById("ElectedAuthor").value;  //被选出来写这一个chapter的ElectedAuthor
let Votes = document.getElementById("Votes").value;  // 这个author得到的票数