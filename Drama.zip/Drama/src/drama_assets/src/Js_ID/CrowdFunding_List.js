let DramaType = document.getElementById("DramaType").value;  // 这个drama 最先提出的type
let DramaTitles = document.getElementById("DramaTitles").value; // 这个drama最先提出的Title
let Proposal = document.getElementById("Proposal").value;  // 这个drama最先提出的proposal
let ProposalAuthor = document.getElementById("ProposalAuthor").value;  // 提出这个drama的proposal的author