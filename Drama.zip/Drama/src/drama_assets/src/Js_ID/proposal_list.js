let ProposalAuthor = document.getElementById("author.id").value;//author.id
let ProposalAuthor = document.getElementById("TokenAmount").value;//TokenAmount
let ProposalAuthor = document.getElementById("author.description").value;//description
let ProposalAuthor = document.getElementById("number").value;//number of vote