import type { Principal } from '@dfinity/principal';
export type ActivityID = bigint;
export type Address = string;
export interface Drama {
  'createUser' : (
      arg_0: string,
      arg_1: string,
      arg_2: string,
      arg_3: string,
      arg_4: string,
    ) => Promise<UserInfo>,
  'dojob' : (arg_0: string) => Promise<string>,
  'getActivityInfo' : (arg_0: ActivityID) => Promise<activityInfoText>,
  'getUser' : (arg_0: string) => Promise<UserInfo>,
  'getWoteWinner' : (arg_0: ActivityID) => Promise<string>,
  'greet' : (arg_0: string) => Promise<string>,
  'partivipaterVote' : (
      arg_0: ActivityID,
      arg_1: Address,
      arg_2: bigint,
    ) => Promise<string>,
  'partivipaterVoteV1' : (
      arg_0: ActivityID,
      arg_1: Address,
      arg_2: bigint,
    ) => Promise<string>,
  'scriptSkillActivitySpon' : (
      arg_0: bigint,
      arg_1: string,
      arg_2: string,
      arg_3: string,
    ) => Promise<bigint>,
  'scriptSkillParinIn' : (arg_0: ActivityID, arg_1: bigint) => Promise<string>,
  'test01' : () => Promise<boolean>,
  'testGet' : () => Promise<string>,
  'testReadMap' : () => Promise<string>,
  'testReadMap1' : () => Promise<bigint>,
  'testReadVar' : () => Promise<string>,
}
export type Time = bigint;
export interface UserInfo {
  'createTime' : Time,
  'email' : string,
  'address' : Address,
  'phone' : string,
  'personalInfo' : string,
  'lastName' : string,
  'firstName' : string,
}
export interface activityInfoText {
  'scriptName' : string,
  'scriptType' : string,
  'activityId' : ActivityID,
  'activitySponsorPrincipal' : string,
  'scriptDescription' : string,
  'timestamp' : bigint,
  'body1' : Array<number>,
  'body2' : Array<number>,
  'body3' : Array<number>,
  'totalBalance' : bigint,
}
export interface _SERVICE extends Drama {}
