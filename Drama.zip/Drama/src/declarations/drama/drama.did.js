export const idlFactory = ({ IDL }) => {
  const Time = IDL.Int;
  const Address = IDL.Text;
  const UserInfo = IDL.Record({
    'createTime' : Time,
    'email' : IDL.Text,
    'address' : Address,
    'phone' : IDL.Text,
    'personalInfo' : IDL.Text,
    'lastName' : IDL.Text,
    'firstName' : IDL.Text,
  });
  const ActivityID = IDL.Nat;
  const activityInfoText = IDL.Record({
    'scriptName' : IDL.Text,
    'scriptType' : IDL.Text,
    'activityId' : ActivityID,
    'activitySponsorPrincipal' : IDL.Text,
    'scriptDescription' : IDL.Text,
    'timestamp' : IDL.Int,
    'body1' : IDL.Vec(IDL.Nat8),
    'body2' : IDL.Vec(IDL.Nat8),
    'body3' : IDL.Vec(IDL.Nat8),
    'totalBalance' : IDL.Nat64,
  });
  const Drama = IDL.Service({
    'createUser' : IDL.Func(
        [IDL.Text, IDL.Text, IDL.Text, IDL.Text, IDL.Text],
        [UserInfo],
        [],
      ),
    'dojob' : IDL.Func([IDL.Text], [IDL.Text], []),
    'getActivityInfo' : IDL.Func([ActivityID], [activityInfoText], ['query']),
    'getUser' : IDL.Func([IDL.Text], [UserInfo], []),
    'getWoteWinner' : IDL.Func([ActivityID], [IDL.Text], []),
    'greet' : IDL.Func([IDL.Text], [IDL.Text], []),
    'partivipaterVote' : IDL.Func(
        [ActivityID, Address, IDL.Nat64],
        [IDL.Text],
        [],
      ),
    'partivipaterVoteV1' : IDL.Func(
        [ActivityID, Address, IDL.Nat64],
        [IDL.Text],
        [],
      ),
    'scriptSkillActivitySpon' : IDL.Func(
        [IDL.Nat64, IDL.Text, IDL.Text, IDL.Text],
        [IDL.Nat],
        [],
      ),
    'scriptSkillParinIn' : IDL.Func([ActivityID, IDL.Nat64], [IDL.Text], []),
    'test01' : IDL.Func([], [IDL.Bool], []),
    'testGet' : IDL.Func([], [IDL.Text], []),
    'testReadMap' : IDL.Func([], [IDL.Text], []),
    'testReadMap1' : IDL.Func([], [IDL.Nat64], []),
    'testReadVar' : IDL.Func([], [IDL.Text], []),
  });
  return Drama;
};
export const init = ({ IDL }) => { return []; };
